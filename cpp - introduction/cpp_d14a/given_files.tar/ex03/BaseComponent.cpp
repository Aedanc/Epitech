#include "BaseComponent.hpp"

BaseComponent::~BaseComponent()
{
}
