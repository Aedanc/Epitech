
#include "Errors.hpp"
#include "AtmosphereRegulator.hpp"

AtmosphereRegulator::AtmosphereRegulator()
{
}

AtmosphereRegulator::~AtmosphereRegulator()
{
}
